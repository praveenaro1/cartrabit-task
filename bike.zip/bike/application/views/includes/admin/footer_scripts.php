<!-- Vendor JS -->
	<script src="<?php echo base_url(); ?>assets/admin/js/vendors.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/pages/chat-popup.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/vendor_components/apexcharts-bundle/dist/apexcharts.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/icons/feather-icons/feather.min.js"></script>	
	
	<script src="<?php echo base_url(); ?>assets/admin/vendor_components/OwlCarousel2/dist/owl.carousel.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/core.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/maps.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/worldLow.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/kelly.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/animated.js"></script>
	
	<!-- Riday App -->
	<script src="<?php echo base_url(); ?>assets/admin/js/template.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/dashboard.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/select2.full.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-select.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-tagsinput.js"></script>	
	<script src="<?php echo base_url(); ?>assets/admin/js/jquery.bootstrap-touchspin.min.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/admin/js/jquery.inputmask.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/jquery.inputmask.date.extensions.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/jquery.inputmask.extensions.js"></script>

	<script src="<?php echo base_url(); ?>assets/admin/js/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/daterangepicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-datepicker.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-colorpicker.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-timepicker.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/admin/js/icheck.min.js"></script>
	
	<!-- Riday App -->	
	<script src="<?php echo base_url(); ?>assets/admin/js/advanced-form-element.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/datatables.min.js"></script>
	<!-- Riday App -->
	<script src="<?php echo base_url(); ?>assets/admin/js/data-table.js"></script>
</body>
</html>
